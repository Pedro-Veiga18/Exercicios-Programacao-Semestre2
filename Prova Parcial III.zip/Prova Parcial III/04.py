#a)
#Não é mais rapido.

#b)
#O quicksort separa em pivo e partir das quebras de listas ele remonta a lista de maneira rapida, enquanto esse ordenar demora mais fazendo comparacoes.